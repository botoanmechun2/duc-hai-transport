# Vận Tải Đức Hải — Website + Admin

## Công nghệ
- Node.js + Express
- SQLite (better-sqlite3)
- HTML/CSS/JavaScript thuần
- Session đăng nhập admin

## Chạy local
1. Cài Node.js 18+.
2. Mở terminal tại thư mục dự án.
3. Chạy:
   npm install
   npm start
4. Mở http://localhost:3000
5. Quản trị: http://localhost:3000/admin

## Tài khoản mặc định
- Username: admin
- Password: DucHai@2026

Nên đổi bằng biến môi trường:
ADMIN_USER=...
ADMIN_PASS=...
SESSION_SECRET=...

## Database
File `duc-hai.db` được tự tạo ở lần chạy đầu tiên.

## API
POST /api/quotes
POST /api/admin/login
POST /api/admin/logout
GET /api/admin/me
GET /api/admin/quotes
GET /api/admin/quotes/:id
PATCH /api/admin/quotes/:id
DELETE /api/admin/quotes/:id
